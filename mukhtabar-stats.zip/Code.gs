/**
 * مختبر الذات — خادم استقبال النتائج
 * يُلصق هذا الملف في Google Apps Script المرتبط بجدول بيانات Google،
 * ثم يُنشر كتطبيق ويب (Web app).
 */

// رمز المدرب: لا تُعرض البيانات إلا لمن يرسل هذا الرمز
const TRAINER_CODE = 'hajrus70';

const SHEET_NAME = 'السجلات';
const COLS = [
  'attempt_id', 'participant_id', 'name', 'contact', 'org', 'group', 'age', 'gender',
  'test_id', 'test_name', 'kind', 'status', 'answered',
  'started_at', 'updated_at', 'completed_at', 'duration_min',
  'score', 'band', 'percentile', 'summary', 'details_json', 'answers_json', 'device'
];
const HEADERS_AR = [
  'رقم المحاولة', 'رقم المشارك', 'الاسم', 'الهاتف/البريد', 'الجهة', 'الدورة', 'الفئة العمرية', 'الجنس',
  'رمز المقياس', 'المقياس', 'النوع', 'الحالة', 'عدد الإجابات',
  'بدأ في', 'آخر تحديث', 'اكتمل في', 'المدة (دقيقة)',
  'الدرجة', 'التصنيف', 'أعلى من (%)', 'الخلاصة', 'التفاصيل', 'الإجابات', 'الجهاز'
];

function sheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.getRange(1, 1, 1, COLS.length).setValues([HEADERS_AR]).setFontWeight('bold');
    sh.getRange(2, 1, 1, COLS.length).setValues([COLS]).setFontColor('#999999');
    sh.setFrozenRows(2);
    sh.setRightToLeft(true);
  }
  return sh;
}

function out_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function authorized_(code) {
  return String(code || '').trim().toLowerCase() === TRAINER_CODE.toLowerCase();
}

function cell_(col, v) {
  if (v === undefined || v === null) return '';
  if (typeof v === 'object') v = JSON.stringify(v);
  // نصوص تبدأ بأرقام أو + (مثل أرقام الهواتف) تُحفظ نصًا كما هي
  if (col === 'contact' || col === 'attempt_id' || col === 'participant_id') return "'" + String(v);
  return v;
}

// استقبال تقدّم المشارك ونتيجته (يُستدعى من صفحات الاختبارات)
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const d = JSON.parse(e.postData.contents);

    // حذف سجلات (من لوحة المدرب فقط)
    if (d.action === 'delete') {
      if (!authorized_(d.code)) return out_({ ok: false, error: 'unauthorized' });
      const sh = sheet_();
      const ids = new Set([].concat(d.attempt_ids || []));
      const pid = d.participant_id || '';
      const vals = sh.getRange(1, 1, sh.getLastRow(), 2).getValues();
      let removed = 0;
      for (let r = vals.length; r >= 3; r--) {
        const a = String(vals[r - 1][0]), p = String(vals[r - 1][1]);
        if (ids.has(a) || (pid && p === pid)) { sh.deleteRow(r); removed++; }
      }
      return out_({ ok: true, removed: removed });
    }

    if (!d.attempt_id || !d.test_id) return out_({ ok: false, error: 'bad request' });
    const sh = sheet_();
    const row = COLS.map(c => cell_(c, d[c]));
    const found = sh.getRange('A:A').createTextFinder(String(d.attempt_id)).matchEntireCell(true).findNext();
    if (found && found.getRow() > 2) {
      const r = found.getRow();
      const old = sh.getRange(r, 1, 1, COLS.length).getValues()[0];
      const iStatus = COLS.indexOf('status'), iStart = COLS.indexOf('started_at');
      // لا تُستبدل نتيجة مكتملة بتحديث تقدّم متأخر
      if (old[iStatus] === 'completed' && d.status !== 'completed') return out_({ ok: true, skipped: true });
      if (old[iStart]) row[iStart] = old[iStart];
      sh.getRange(r, 1, 1, COLS.length).setValues([row]);
    } else {
      sh.appendRow(row);
    }
    return out_({ ok: true });
  } catch (err) {
    return out_({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

// قراءة كل السجلات (للوحة المدرب فقط)
function doGet(e) {
  const p = (e && e.parameter) || {};
  if (!authorized_(p.code)) return out_({ ok: false, error: 'unauthorized' });
  const sh = sheet_();
  const last = sh.getLastRow();
  if (last < 3) return out_({ ok: true, rows: [] });
  const vals = sh.getRange(3, 1, last - 2, COLS.length).getValues();
  const rows = vals.map(r => {
    const o = {};
    COLS.forEach((c, i) => { const v = r[i]; o[c] = v instanceof Date ? v.toISOString() : v; });
    return o;
  });
  return out_({ ok: true, rows: rows });
}
